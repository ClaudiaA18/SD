#ifndef C_PROJECT_MAIN_H
#define C_PROJECT_MAIN_H


#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdint.h>
#include <math.h>

#define MAX_LINE_LENGTH 1024

// STRUCTURA CERUTA:

typedef struct QuadTreeNode {
    unsigned char blue, green, red;
    uint32_t area;
    uint32_t top_left, top_right;
    uint32_t bottom_left, bottom_right;
} __attribute__ ((packed)) QuadTreeNode;

// datele unui arbore cuaternal, conform cerintei, adica ceea ce salvam in fisierul binar pt o
//  imagine comprimata
typedef struct CompressedImage {
    uint32_t numar_culori;
    uint32_t numar_noduri;
    QuadTreeNode *noduri;
} __attribute__ ((packed)) CompressedImage;

// pixeli din grid-ul imaginii
typedef struct {
    unsigned char red, green, blue;
} Pixel;

// iteram mai usor zonele din imagine cand vom crea arborele
typedef struct {
    uint32_t startX, startY, sideLength;
    Pixel **grid;
} Area;

// structura care retine datele unui fisier PPM
typedef struct {
    char type[11];
    uint32_t width, height, maxColor;
    // how many characters until the body:
    uint32_t headerLength;
    // the body
    Pixel **grid;
} PpmImage;

// Functii utile:

PpmImage readPpmImage(char *file) {

    FILE *f;
    PpmImage image;

    f = fopen(file, "r");

    fgets(image.type, 10, f);
    fscanf(f, "%d %d %d", &image.width, &image.height,
           &image.maxColor); // read P6 message, width, height, and 256=maximum value for a channel

    // citim primele 3 linii (header) ca sa gasim de unde incep pixelii (grid-ul)
    f = fopen(file, "r");
    image.headerLength = 0;
    char buf[1025];
    for (int i = 0; i < 3; ++i) {
        fgets(buf, MAX_LINE_LENGTH, f);
        image.headerLength += strlen(buf);
    }

    // citim andetul imaginii

    f = fopen(file, "rb");
    char buffer[MAX_LINE_LENGTH * 3]; // enough memory for the three header lines
    // citim antetul imaginii
    fread(buffer, image.headerLength, 1, f);

    // citim corpul
    image.grid = (Pixel **) malloc(image.height * sizeof(Pixel *));
    for (int i = 0; i < image.height; ++i) {
        image.grid[i] = (Pixel *) malloc(image.width * sizeof(Pixel));
    }
    for (int i = 0; i < image.height; ++i) {
        for (int j = 0; j < image.width; ++j) {
            fread(&image.grid[i][j].red, sizeof(unsigned char), 1, f);
            fread(&image.grid[i][j].green, sizeof(unsigned char), 1, f);
            fread(&image.grid[i][j].blue, sizeof(unsigned char), 1, f);
        }
    }

    return image;
}

void freePpmImage(PpmImage img) {
    for (int i = 0; i < img.height; ++i) {
        free(img.grid[i]);
    }
    free(img.grid);
}

void freeCompressedImage(CompressedImage cImg) {
    free(cImg.noduri);
}

void writeBinary(CompressedImage img, char *file) {
    FILE *f;
    f = fopen(file, "wb");

    fwrite(&img.numar_culori, sizeof(img.numar_culori), 1, f);
    fwrite(&img.numar_noduri, sizeof(img.numar_noduri), 1, f);

    for (int i = 0; i < img.numar_noduri; ++i) {
        fwrite(&img.noduri[i], sizeof(QuadTreeNode), 1, f);
    }

    fclose(f);

}


int hasNewColor(Pixel *colors, int cntNodes, Pixel newColor) {
    for (int i = 0; i < cntNodes; ++i) {
        if (colors[i].red == newColor.red &&
            colors[i].green == newColor.green &&
            colors[i].blue == newColor.blue) {
            return 0;
        }
    }
    return 1;
}

QuadTreeNode fillMeanColor(Area area) {
    uint32_t rSum = 0, gSum = 0, bSum = 0;
    for (int i = area.startX; i < area.startX + area.sideLength; ++i) {
        for (int j = area.startY; j < area.startY + area.sideLength; ++j) {
            rSum += area.grid[i][j].red;
            gSum += area.grid[i][j].green;
            bSum += area.grid[i][j].blue;
        }
    }

    QuadTreeNode node;
    node.area = area.sideLength * area.sideLength;
    node.red = rSum / node.area;
    node.green = gSum / node.area;
    node.blue = bSum / node.area;

    return node;
}

QuadTreeNode compressArea(Area area) {
    QuadTreeNode node = fillMeanColor(area);
    // we add -1 = maximum value, because we know it will have no more sons:
    node.top_left = -1;
    node.top_right = -1;
    node.bottom_left = -1;
    node.bottom_right = -1;

    return node;
}

double computeScore(Area area) {
    uint32_t rSum = 0, gSum = 0, bSum = 0, sum;
    uint32_t red, green, blue;
    for (int i = area.startX; i < area.startX + area.sideLength; ++i) {
        for (int j = area.startY; j < area.startY + area.sideLength; ++j) {
            rSum += area.grid[i][j].red;
            gSum += area.grid[i][j].green;
            bSum += area.grid[i][j].blue;
        }
    }

    red = rSum / (area.sideLength * area.sideLength);
    green = gSum / (area.sideLength * area.sideLength);
    blue = bSum / (area.sideLength * area.sideLength);

    sum = 0;
    for (int i = area.startX; i < area.startX + area.sideLength; ++i) {
        for (int j = area.startY; j < area.startY + area.sideLength; ++j) {
            sum += (red - area.grid[i][j].red) * (red - area.grid[i][j].red);
            sum += (green - area.grid[i][j].green) * (green - area.grid[i][j].green);
            sum += (blue - area.grid[i][j].blue) * (blue - area.grid[i][j].blue);
        }
    }

    return sum / (3 * area.sideLength * area.sideLength);
}


CompressedImage cerinta1_compressImage(PpmImage img, int compressionScore) {
    // in cel mai raz caz, vom avea width*height*log(width*height) noduri in arbore, asezate precum o piramida:
    int logOfArea =
            log(img.width * img.height) / log(4) + 1; // calculam logaritmul + 1 pt a avea coada suficient de lunga
    // vom folosi o coada pentru a parcurge zonele si crea arborele
    Area *queue = malloc(logOfArea * img.width * img.height * sizeof(Area));
    Area area;
    int lt, rt;
    // use an array for storing the

    lt = rt = 0;
    queue[0].startX = 0;
    queue[0].startY = 0;
    queue[0].sideLength = img.width;
    queue[0].grid = img.grid;
    QuadTreeNode *vector = malloc(logOfArea * img.width * img.height * sizeof(QuadTreeNode));
    // for each area inside queue, there is a quad node in vector

    // TODO add a pixel vector
    Pixel *colors = malloc(img.width * img.height * sizeof(Pixel)), color;
    int cntColors = 0;

    while (lt <= rt) {
        // extract the area to split into 4 areas:
        area = queue[lt];

        // if area is not terminal, meaning that the score is less than the compressionScore
        // TODO does it work for area of sideLength equal to 1?
        if (computeScore(area) <= compressionScore) {
            vector[lt] = compressArea(area);
            color.blue = vector[lt].blue;
            color.red = vector[lt].red;
            color.green = vector[lt].green;
            if (hasNewColor(colors, cntColors, color)) {
                cntColors++;
                colors[cntColors++] = color;
            }
        } else {
            // complete vector[lt]
            vector[lt] = fillMeanColor(area);
            // split the area:
            rt++;
            queue[rt].grid = img.grid;
            queue[rt].sideLength = area.sideLength / 2;
            queue[rt].startX = area.startX;
            queue[rt].startY = area.startY;
            vector[lt].top_left = rt;
            rt++;
            queue[rt].grid = img.grid;
            queue[rt].sideLength = area.sideLength / 2;
            queue[rt].startX = area.startX;
            queue[rt].startY = area.startY + queue[rt].sideLength;
            vector[lt].top_right = rt;
            rt++;
            queue[rt].grid = img.grid;
            queue[rt].sideLength = area.sideLength / 2;
            queue[rt].startX = area.startX + queue[rt].sideLength;
            queue[rt].startY = area.startY + queue[rt].sideLength;
            vector[lt].bottom_right = rt;
            rt++;
            queue[rt].grid = img.grid;
            queue[rt].sideLength = area.sideLength / 2;
            queue[rt].startX = area.startX + queue[rt].sideLength;
            queue[rt].startY = area.startY;
            vector[lt].bottom_left = rt;
        }
        lt++;
    }

    free(queue); // dezalocam coada
    free(colors); // dezalocam vectorul de culori
    CompressedImage output;
    output.numar_culori = cntColors;
    output.numar_noduri = lt;
    output.noduri = vector;
    return output;

}

CompressedImage readCompressedImg(char *file) {
    FILE *f;
    f = fopen(file, "rb");

    CompressedImage cImg;
    fread(&cImg.numar_culori, 1, sizeof(cImg.numar_culori), f);
    fread(&cImg.numar_noduri, 1, sizeof(cImg.numar_noduri), f);

    cImg.noduri = malloc(cImg.numar_noduri * sizeof(QuadTreeNode));
    for (int i = 0; i < cImg.numar_noduri; ++i) {
        fread(&cImg.noduri[i], 1, sizeof(QuadTreeNode), f);
    }

    return cImg;
}

int isTerminalNode(QuadTreeNode node) {
    if (node.top_left == -1 &&
        node.top_right == -1 &&
        node.bottom_left == -1 &&
        node.bottom_right == -1) {
        return 1;
    } else {
        return 0;
    }
}

void fillPixels(QuadTreeNode *nodes, uint32_t nodeIndex,
                int x1, int y1, int sideLength,
                PpmImage img) {
    QuadTreeNode node = nodes[nodeIndex];
    if (isTerminalNode(node)) {
        for (int x = x1; x < x1 + sideLength; ++x) {
            for (int y = y1; y < y1 + sideLength; ++y) {
                img.grid[x][y].blue = node.blue;
                img.grid[x][y].red = node.red;
                img.grid[x][y].green = node.green;
            }
        }
    } else {
        fillPixels(nodes, node.top_left,
                   x1, y1, sideLength / 2, img);
        fillPixels(nodes, node.top_right,
                   x1, y1 + sideLength / 2, sideLength / 2, img);
        fillPixels(nodes, node.bottom_left,
                   x1 + sideLength / 2, y1, sideLength / 2, img);
        fillPixels(nodes, node.bottom_right,
                   x1 + sideLength / 2, y1 + sideLength / 2, sideLength / 2, img);
    }
}


PpmImage decompressImage(CompressedImage cImg) {
    PpmImage img;

    // gasim valorile pentru type, width, height
    img.height = (int) sqrt(cImg.noduri[0].area);
    img.width = img.height;
    img.maxColor = 255; // TODO is it always 255?

    // alocam memoria pentru grid
    img.grid = (Pixel **) malloc(img.height * sizeof(Pixel *));
    for (int i = 0; i < img.height; ++i) {
        img.grid[i] = (Pixel *) malloc(img.width * sizeof(Pixel));
    }

    // Vom folosi fillPixels care parcurge nodurile si seteaza pixelii pentru fiecare nod terminal

    fillPixels(cImg.noduri, 0, 0, 0, (int) sqrt(cImg.noduri[0].area), img);

    return img;
}


void writePpmImage(PpmImage img, char *file) {
    char headerBuf[1024 * 3];
    sprintf(headerBuf, "P6\n%d %d\n%d\n", img.width, img.height, img.maxColor);

    FILE *f;
    f = fopen(file, "wb");

    // scriem headerul
    fwrite(headerBuf, strlen(headerBuf), 1, f);
    // scriem pixelii in ordinea si formatul din cerinta
    for (int i = 0; i < img.height; ++i) {
        for (int j = 0; j < img.width; ++j) {
            fwrite(&img.grid[i][j], sizeof(unsigned char) * 3, 1, f);
        }
    }

    fclose(f);
}


CompressedImage mirrored(CompressedImage img, char *direction) {
    // facem o copie a imaginii
    CompressedImage mImg = img;
    mImg.noduri = (QuadTreeNode *) malloc(img.numar_noduri * sizeof(QuadTreeNode));
    for (int i = 0; i < img.numar_noduri; ++i) {
        mImg.noduri[i] = img.noduri[i];
    }
    // oglindim imaginea
    int tmp;
    for (int i = 0; i < mImg.numar_noduri; ++i) {
        if (strcmp(direction, "h") == 0) {
            tmp = mImg.noduri[i].top_left;
            mImg.noduri[i].top_left = mImg.noduri[i].top_right;
            mImg.noduri[i].top_right = tmp;

            tmp = mImg.noduri[i].bottom_left;
            mImg.noduri[i].bottom_left = mImg.noduri[i].bottom_right;
            mImg.noduri[i].bottom_right = tmp;
        } else { // alte cazuri, precum strcmp(direction, "v") == 0
            tmp = mImg.noduri[i].top_left;
            mImg.noduri[i].top_left = mImg.noduri[i].bottom_left;
            mImg.noduri[i].bottom_left = tmp;

            tmp = mImg.noduri[i].top_right;
            mImg.noduri[i].top_right = mImg.noduri[i].bottom_right;
            mImg.noduri[i].bottom_right = tmp;
        }
    }

    return mImg;
}


int main(int argc, char *argv[]) {


    int compressionScore;
    char fin[1000], fout[1000];
    char mirrorDirection[10];
    CompressedImage cImg, mImg;

    if (strcmp(argv[1], "-c") == 0) { // Task 1
        sscanf(argv[2], "%d", &compressionScore);
        strcpy(fin, argv[3]);
        strcpy(fout, argv[4]);
        // folosim fin pentru a citi imaginea PPM si fout pentru a scrie imaginea comprimata
        PpmImage img = readPpmImage(fin);
        cImg = cerinta1_compressImage(img, compressionScore);
        writeBinary(cImg, fout);
        // dezalocam memoria
        freePpmImage(img);
        freeCompressedImage(cImg);
    } else if (strcmp(argv[1], "-d") == 0) { // Task 2
        strcpy(fin, argv[2]);
        strcpy(fout, argv[3]);
        // folosim fin pentru a citi fisierul comprimat de la cerinta 1,
        //  , iar fout pentru a scrie imaginea rezultata=
        cImg = readCompressedImg(fin);
        PpmImage decompressedImg = decompressImage(cImg);
        writePpmImage(decompressedImg, fout);
        // dezalocam memoria
        freePpmImage(decompressedImg);
        freeCompressedImage(cImg);

    } else if (strcmp(argv[1], "-m") == 0) {
        strcpy(mirrorDirection, argv[2]);
        sscanf(argv[3], "%d", &compressionScore);
        strcpy(fin, argv[4]);
        strcpy(fout, argv[5]);
        // fin este imaginea PPM primita ca input , iar  fout este imaginea PPM dupa oglindire
        PpmImage img = readPpmImage(fin);
        cImg = cerinta1_compressImage(img, compressionScore);
        mImg = mirrored(cImg, mirrorDirection);
        img = decompressImage(mImg);
        writePpmImage(img, fout);
        // dezalocam memoria
        freePpmImage(img);
        freeCompressedImage(cImg);
        freeCompressedImage(mImg);
    }

    return 0;
}

#endif //C_PROJECT_MAIN_H


